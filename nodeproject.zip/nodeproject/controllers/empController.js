const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const employee = mongoose.model('empModel');